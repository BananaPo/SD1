CHAT_SERVER_HOST = "172.31.91.151"
CHAT_SERVER_PORT = 5001

# IDs de usuários registrados com os respectivos endereços IP e números de porta
registry = {"Alice":("172.31.82.97",5002), "Bob":("172.31.89.197",5002)}
